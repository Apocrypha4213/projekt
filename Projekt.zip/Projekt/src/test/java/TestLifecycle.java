public class TestLifecycle {
    public void setUp() {
        System.out.println("set up");
        System.out.flush();
    }

    public void tearDown() {
        System.out.println("tear down");
        System.out.flush();
    }

    public static void setUpClass() {
        System.out.println("set up class");
        System.out.flush();
    }

    public static void tearDownClass() {
        System.out.println("tear down class");
        System.out.flush();
    }

    public void test1() {
        System.out.println("test 1");
        System.out.flush();
    }

    public void test2() {
        System.out.println("test 2");
        System.out.flush();
    }
}