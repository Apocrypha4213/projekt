import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;


public class Main extends JFrame{
    JButton button1;
    JLabel label;

    public Main(){
        super("Przegladarka plikow graficznych"); //ustala nazwe okna
        button1 = new JButton("Wybierz plik"); //tworzy nowy przycisk ktory bedzie podpisany jako "Wybierz plik"
        button1.setBounds(300,630,200,40); //ustala rozmiar oraz polozenie przycisku
        label = new JLabel(); // mozliwosc wyswietlenia obrazu
        label.setBounds(10,10,800,600); //ustala w jakim miejscu na oknie programu ma sie pojawic obraz i jaki ma byc jego rozmiar
        add(button1); //dodaje przycisk
        add(label); //dodaje obraz


        button1.addActionListener(new ActionListener() { //akcja przycisku button1
            public void actionPerformed(ActionEvent e) {
                JFileChooser file = new JFileChooser(); // tworzenie nowej opcji umozliwiajacej wybieranie plikow
                file.setCurrentDirectory(new File(System.getProperty("user.home"))); //po nacisnieciu przycsku folderem startowym bedzie
                // folder uzytkownika

                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.zdjecia", "jpg","gif","png"); //tworzenie dodatkowej opcji
                // filtrowania zamiast wyboru wszystkich plikow. Po wybraniu tej opcji do wyboru pozostana jedynie foldery oraz pliki o
                // podanych rozszerzeniach
                file.addChoosableFileFilter(filter); //dodanie tej opcji
                int result = file.showSaveDialog(null);

                if(result == JFileChooser.APPROVE_OPTION){ //w przypadku kiedy zaakceptowalo sie plik
                    File selectedFile = file.getSelectedFile();
                    String path = selectedFile.getAbsolutePath();
                    label.setIcon(ResizeImage(path)); //skalowanie obrazu do odpowiedniej wielkosci
                }
            }
        });

        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(840,720); //rozmair okna
        setVisible(true);
    }

    public ImageIcon ResizeImage(String ImagePath) //zmienia rozmiar wybranego zdjecia i zwraca go
    {
        ImageIcon MyImage = new ImageIcon(ImagePath);
        Image img = MyImage.getImage();
        Image newImg = img.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImg);
        return image;
    }

    public static void main(String[] args){
        new Main();
    } // wywolujemy funkcje Main();
}